package com.nt.test;

import java.util.Scanner;

import org.springframework.beans.factory.support.DefaultListableBeanFactory;
import org.springframework.beans.factory.xml.XmlBeanDefinitionReader;

import com.nt.controller.Maincotrolleer;
import com.nt.vo.CustomerVO;

public class RealtimeDITest {
	
	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter customer name");
		String name = sc.next();
		System.out.println("Enter customer address");
		String add = sc.next();
		System.out.println("Enter customer principle amt");
		String pAmt = sc.next();
		System.out.print("Enter the rate of interest");
		String rate = sc.next();
		System.out.println("Enter the time");
		String time = sc.next();
		
		CustomerVO vo = new CustomerVO();
		vo.setCustName(name);
		vo.setCustAddrs(add);
		vo.setPamt(pAmt);
		vo.setRate(rate);
		vo.setTime(time);
		
		DefaultListableBeanFactory fac = new DefaultListableBeanFactory();
		XmlBeanDefinitionReader reader = new XmlBeanDefinitionReader(fac);
		reader.loadBeanDefinitions("com/nt/cfgs/Applicationconf.xml");
		
		Maincotrolleer controller = fac.getBean("controller",Maincotrolleer.class);
		try {
			String result = controller.processCustomer(vo);
			System.out.println(result);
			
		}
		catch(Exception e) {
			e.printStackTrace();
			System.out.print("INTERNAL PROBLEM");
			
		}
	}

}
