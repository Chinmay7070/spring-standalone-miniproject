package com.nt.service;

import com.nt.dto.CustomerDto;

public interface ICustomerManagement {
      public String calculatesimpleinterest(CustomerDto dto) throws Exception;
}
