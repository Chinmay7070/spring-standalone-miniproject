package com.nt.service;

import com.nt.bo.CustomerBO;
import com.nt.dao.ICostomerDAO;
import com.nt.dto.CustomerDto;

public final class CustomermanagementserviceImpl implements ICustomerManagement {
	
	private ICostomerDAO dao;
	
	public CustomermanagementserviceImpl(ICostomerDAO dao) {
	    System.out.println("CustomerMgt ");
	    this.dao = dao;
	}
	

	@Override
	public String calculatesimpleinterest(CustomerDto dto) throws Exception {
		float intrAmt =(dto.getPamt()*dto.getRate()*dto.getTime())/100.0f;
		
		// Creating bo class obj having persitable data 
		
		 CustomerBO bo = new CustomerBO();
		 bo.setCustName(dto.getCustName());
		 bo.setCustAddrs(dto.getCustAddrs());
		 bo.setPamt(dto.getPamt());
		 bo.setTime(dto.getTime());
		 bo.setRate(dto.getRate());
		 bo.setIntrestAmount(intrAmt);  
		 
		 int count = dao.insert(bo);		   
		return count == 1 ? "Customer registered successfully : simpleinterest = "+intrAmt :"registration flil";
	}

}
