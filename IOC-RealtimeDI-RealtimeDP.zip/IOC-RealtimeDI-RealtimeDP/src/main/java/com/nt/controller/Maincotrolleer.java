package com.nt.controller;

import com.nt.dto.CustomerDto;
import com.nt.service.ICustomerManagement;
import com.nt.vo.CustomerVO;

public class Maincotrolleer {
   private ICustomerManagement service;
   
   public Maincotrolleer(ICustomerManagement service) {
	   System.out.println("maincontroller.Manintroller()");
	   this.service = service;
   }
   
   public String processCustomer(CustomerVO vo) throws Exception {
	   
	   
	CustomerDto dto = new CustomerDto();
	
	dto.setCustName(vo.getCustName());
	dto.setCustAddrs(vo.getCustAddrs());
     dto.setPamt(Float.parseFloat(vo.getPamt()));
     dto.setRate(Float.parseFloat(vo.getRate()));
     dto.setTime(Float.parseFloat(vo.getTime()));
     
     String result = service.calculatesimpleinterest(dto);
     
     return result;
	
	   
	   
	   
   }
   
}
