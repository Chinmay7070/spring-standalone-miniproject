package com.nt.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import javax.sql.DataSource;

import com.nt.bo.CustomerBO;

public class CustomerDSOImpl implements ICostomerDAO {
	
	private static final String REALTIMEDI_CUSTOMER_INSERT_QUERY = "INSERT INTO customer VALUES(?,?,?,?,?,?)";
	
	private DataSource ds;

	public CustomerDSOImpl(DataSource ds) {
	    System.out.println("CustormerDaoimpl : 1-param constructor");
		this.ds = ds;
	}

	public int insert(CustomerBO bo) throws Exception {
		Connection conn  = null;
		PreparedStatement ps = null;
		int count = 0;
		try {
			conn = ds.getConnection();
			
			ps = conn.prepareStatement(REALTIMEDI_CUSTOMER_INSERT_QUERY );
			ps.setString(1, bo.getCustName());
			ps.setString(2, bo.getCustAddrs());
			ps.setFloat(3, bo.getPamt());
			ps.setFloat(4, bo.getTime());
			ps.setFloat(5, bo.getRate());
			ps.setFloat(6, bo.getIntrestAmount());
			
			count = ps.executeUpdate();	
			
		} catch (SQLException se) {
			se.printStackTrace();
			throw se;
		} catch (Exception e) {
			e.printStackTrace();
			throw e; //EXCEPTION RETHROWING;
		} finally {
			try {
				if (ps != null)
					ps.close();
			} catch (SQLException se) {
				se.printStackTrace();
				throw se;
			}
			try {
				if (conn != null)
					conn.close();
			} catch (SQLException se) {
				se.printStackTrace();
				throw se;
			}
		}
		return count;
	}
}
