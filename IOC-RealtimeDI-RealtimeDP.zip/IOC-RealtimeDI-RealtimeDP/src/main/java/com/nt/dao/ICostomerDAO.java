package com.nt.dao;

import com.nt.bo.CustomerBO;

public interface ICostomerDAO {
	
	public int insert(CustomerBO bo) throws Exception;

}
